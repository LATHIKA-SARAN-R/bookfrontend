import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Button, Form } from 'semantic-ui-react';

function BookAdd() {
  const [isbn, setIsbn] = useState('');
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [publicationyear, setPublicationyear] = useState('');
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  const handleSubmit = (e) => {
    e.preventDefault();

   
    const formattedDate = new Date(publicationyear).toISOString().split('T')[0];

    const book = {
      isbn,
      title,
      author,
      publicationyear: formattedDate
    };

    axios.post('http://localhost:8085/book/addBook', book, {
      headers: { 
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })
    .then(() => {
      alert('Book added successfully');
      navigate('/books');
    })
    .catch(error => {
      console.error('Error adding book:', error.response?.data || error.message);
      alert(`Failed to add book: ${error.response?.data?.message || error.message}`);
    });
  };

  return (
    <div className="book-add-container">
      <h2>Add Book</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Input
          label="ISBN"
          type="text"
          value={isbn}
          onChange={(e) => setIsbn(e.target.value)}
          required
        />
        <Form.Input
          label="Title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <Form.Input
          label="Author"
          type="text"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          required
        />
        <Form.Input
          label="Publication Year"
          type="date"
          value={publicationyear}
          onChange={(e) => setPublicationyear(e.target.value)}
          required
        />
        <Button primary type="submit">Add Book</Button>
      </Form>
    </div>
  );
}

export default BookAdd;
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { Button, Table } from 'semantic-ui-react';
import './BookList.css';


function BookList() {
  const [books, setBooks] = useState([]);
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = () => {
    axios.get('http://localhost:8085/book/getAllBooks', {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(response => setBooks(response.data))
    .catch(error => console.error('Error fetching books:', error));
  };

  const deleteBook = (isbn) => {
    axios.delete(`http://localhost:8085/book/removeBook/${isbn}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(() => {
      alert('Book deleted successfully');
      fetchBooks();
    })
    .catch(error => alert('Error deleting book'));
  };

  return (
    <div className="book-list-container">
      <h2>Book List</h2>
      <Button primary onClick={() => navigate('/books/add')}>Add New Book</Button>
      <Table celled>
        <thead>
          <tr>
            <th>ISBN</th>
            <th>Title</th>
            <th>Author</th>
            <th>Publication Year</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.map(book => (
            <tr key={book.isbn}>
              <td>{book.isbn}</td>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.publicationyear}</td>
              <td>
                <Button color="blue" onClick={() => navigate(`/books/edit/${book.isbn}`)}>Edit</Button>
                <Button color="red" onClick={() => deleteBook(book.isbn)}>Delete</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
}

export default BookList;
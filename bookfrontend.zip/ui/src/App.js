import { Navigate, Route, Routes } from 'react-router-dom';
import './App.css';
import Login from './Login';
import SignUp from './SignUp';
import BookList from './BookList';
import BookAdd from './BookAdd';
import BookEdit from './BookEdit';

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<SignUp />} />
      <Route path="/books" element={<BookList />} />
      <Route path="/books/add" element={<BookAdd />} />
      <Route path="/books/edit/:isbn" element={<BookEdit />} />
      <Route path="/" element={<Navigate to="/login" />} />
    </Routes>
  );
}

export default App;
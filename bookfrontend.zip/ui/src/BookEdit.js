import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import { Button, Form } from 'semantic-ui-react';

function BookEdit() {
  const { isbn } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState({
    title: '',
    author: '',
    publicationyear: ''
  });
  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.get(`http://localhost:8085/book/viewABook/${isbn}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(response => {
      
      const bookData = response.data;
      if (bookData.publicationyear) {
        bookData.publicationyear = bookData.publicationyear.split('T')[0];
      }
      setBook(bookData);
    })
    .catch(error => {
      console.error('Error fetching book:', error);
      alert('Could not load book');
    });
  }, [isbn]);

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
   
    const formattedBook = {
      ...book,
      publicationyear: new Date(book.publicationyear).toISOString().split('T')[0]
    };

    axios.put(`http://localhost:8085/book/updateBook/${isbn}`, formattedBook, {
      headers: { 
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    })
    .then(() => {
      alert('Book updated successfully');
      navigate('/books');
    })
    .catch(error => {
      console.error('Error updating book:', error);
      alert(`Failed to update book: ${error.response?.data?.message || error.message}`);
    });
  };

  return (
    <div className="book-edit-container">
      <h2>Edit Book</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Input
          label="Title"
          type="text"
          name="title"
          value={book.title}
          onChange={handleChange}
          required
        />
        <Form.Input
          label="Author"
          type="text"
          name="author"
          value={book.author}
          onChange={handleChange}
          required
        />
        <Form.Input
          label="Publication Year"
          type="date"
          name="publicationyear"
          value={book.publicationyear}
          onChange={handleChange}
          required
        />
        <Button primary type="submit">Update Book</Button>
      </Form>
    </div>
  );
}

export default BookEdit;